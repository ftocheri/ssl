<?

class crud extends AppController {
	
	public function __construct($parent) {
		$this->parent=$parent;

		if(!@$_SESSION["isloggedin"] || @$_SESSION["isloggedin"]!="1"){
			header("location:/login?msg=Not Allowed");
		}
	}

	public function index(){

		$data = array();
		$data["pagename"] = "crud";
		$data["navigation"] = array("home"=>"/home", "login"=>"/login", "register"=>"/register", "examples"=>"/examples");
		$data["message"] = $_SESSION["message"];
		$data["email"] = $_SESSION["useremail"];

		$this->parent->getView("header",$data);
		$this->parent->getView("crud", $data);
		$this->parent->getView("footer");
	}

}

?>