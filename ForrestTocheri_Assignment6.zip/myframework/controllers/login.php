<?

class login extends AppController {
	
	public function __construct($parent) {
		$this->parent=$parent;
	}

	public function index(){
		$data = array();
		$data["pagename"] = "login";
		$data["navigation"] = array("home"=>"/home", "login"=>"/login", "register"=>"/register", "examples"=>"/examples");

		$this->parent->getView("header",$data);
		$this->parent->getView("loginForms");
		$this->parent->getView("footer");
	}

	public function recv() {
		if($_POST['type'] == "form") {
			$this->recvForm();
		}
		else {
			$this->recvAjax();
		}
	}

	public function recvForm() {
		$email = $_POST['email'];
		$pass = $_POST['password'];

		$myfile = "./assets/accounts.txt";
		$lines = file($myfile);
		$count = 0;
		foreach($lines as $value) {
			${"line$count"} = $value;
			$count++;
		}
		$info1 = explode("|", $line0);
		$info2 = explode("|", $line1);

		if($email == strtolower($info1[0]) && $pass == $info1[1]) {

			$_SESSION["isloggedin"] = "1";
			$_SESSION["useremail"] = $email;
			$_SESSION["message"] = $info1[2];
			header("location:/crud");

		}
		elseif ($email == strtolower($info2[0]) && $pass == $info2[1]) {
			$_SESSION["isloggedin"] = "1";
			$_SESSION["useremail"] = $email;
			$_SESSION["message"] = $info2[2];
			header("location:/crud");
		}
		else {	
			$_SESSION["isloggedin"] = "0";
			$_SESSION["useremail"] = "";
			header("location:/login?msg=Invalid User");

		}
	}

	public function recvAjax() {
		$email = $_POST['email'];
		$pass = $_POST['password'];
		if($email == "forrest@aol.com" && $pass == "1234") {
			echo "good";
		}
		else {
			echo "bad";
		}
	}
}

?>