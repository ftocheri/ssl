<?php
//app start
include 'bin/config.php';


?>